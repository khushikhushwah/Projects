import pyttsx3

engine = pyttsx3.init()
engine.say("Braille converter test successful.")
engine.runAndWait()
