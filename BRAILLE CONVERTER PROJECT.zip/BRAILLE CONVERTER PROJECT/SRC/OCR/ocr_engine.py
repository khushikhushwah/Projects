import pytesseract
from PIL import Image
import cv2

# Set the Tesseract executable path
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# Image preprocessing for better OCR accuracy
def preprocess_image(image_path):
    # Load the image using OpenCV
    img = cv2.imread(image_path)
    
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Apply thresholding to improve text visibility
    _, thresh = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
    
    return thresh

# OCR Function with preprocessing
def extract_text_from_image(image_path):
    # Preprocess the image first
    processed_image = preprocess_image(image_path)
    
    # Use pytesseract to extract text
    extracted_text = pytesseract.image_to_string(processed_image, lang='eng')
    
    return extracted_text.strip()
