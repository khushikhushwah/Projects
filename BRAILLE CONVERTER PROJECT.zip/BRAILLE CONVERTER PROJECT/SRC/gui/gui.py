import sys
import os
import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import pyttsx3

# Ensure proper path setup for module imports
SRC_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.append(SRC_DIR)

from OCR.ocr_engine import extract_text_from_image
from Braille.braille_converter import convert_to_braille

# Initialize the Tkinter window
root = tk.Tk()
root.title("Braille Converter")
root.geometry("800x650")  # Increased size for image preview

# Function to speak text using pyttsx3
def speak_text(text):
    if text.strip():
        try:
            engine = pyttsx3.init()
            voices = engine.getProperty('voices')
            engine.setProperty('voice', voices[0].id)  # Force default voice
            engine.setProperty('rate', 150)
            engine.say(text)
            engine.runAndWait()
        except Exception as e:
            messagebox.showerror("TTS Error", f"Could not speak:\n{e}")
    else:
        messagebox.showwarning("Warning", "No text to speak.")


# Function to upload and process image
def upload_image():
    file_path = filedialog.askopenfilename(
        title="Select Image File",
        filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp")]
    )
    if file_path:
        try:
            # === Display the image ===
            img = Image.open(file_path)
            img = img.resize((300, 300))
            img_tk = ImageTk.PhotoImage(img)
            image_label.configure(image=img_tk)
            image_label.image = img_tk  # Keep reference

            # === OCR and Braille Conversion ===
            extracted_text = extract_text_from_image(file_path)
            if extracted_text:
                braille_output = convert_to_braille(extracted_text)
                braille_output_text.delete(1.0, tk.END)
                braille_output_text.insert(tk.END, braille_output)
            else:
                messagebox.showerror("Error", "No text detected in the image.")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred:\n{e}")

# Function to save Braille output
def save_output():
    braille_text = braille_output_text.get(1.0, tk.END).strip()
    if braille_text:
        file_path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text Files", "*.txt")]
        )
        if file_path:
            try:
                with open(file_path, "w", encoding="utf-8") as file:
                    file.write(braille_text)
                messagebox.showinfo("Success", "Braille output saved successfully.")
            except Exception as e:
                messagebox.showerror("Save Error", f"Could not save file:\n{e}")
    else:
        messagebox.showwarning("Warning", "No Braille output to save.")

# Function to speak the Braille output
def speak_output():
    braille_text = braille_output_text.get(1.0, tk.END).strip()
    speak_text(braille_text)

# === GUI Components ===
upload_button = tk.Button(root, text="Upload Image", command=upload_image)
upload_button.pack(pady=10)

image_label = tk.Label(root)  # Label to show uploaded image
image_label.pack(pady=5)

braille_output_text = tk.Text(root, wrap=tk.WORD, height=10, width=70, font=("Arial", 14))
braille_output_text.pack(pady=10)

save_button = tk.Button(root, text="Save Braille Output", command=save_output)
save_button.pack(pady=5)

speak_button = tk.Button(root, text="Speak Braille Output", command=speak_output)
speak_button.pack(pady=5)

# Run the application
root.mainloop()
