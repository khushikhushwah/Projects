import pyttsx3

engine = pyttsx3.init()
voices = engine.getProperty('voices')

# Try different voices if needed
engine.setProperty('voice', voices[0].id)  
engine.setProperty('rate', 150)

print("Speaking...")
engine.say("Hello! This is your Braille converter speaking.")
engine.runAndWait()
print("Done.")
